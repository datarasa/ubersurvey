<?php

     print drupal_render($summary);

